BugWindow - Aurorae window decoration for KDE Plasma 6 (KWin)

=========================================================================
WHY THE TITLE COLOR / CENTER DID NOT CHANGE LAST TIME (important!)
=========================================================================
KWin reads the button SVGs by file path, so they update on any re-render -
that is why the new buttons showed up. BUT the theme config file (BugWindowrc:
title color, alignment, sizes) is ONLY read when the decoration is
re-created (KWin's Decoration::init()). Clicking "Apply" on the same theme,
or just re-selecting it, does NOT always re-create it - so the rc was ignored
and the title stayed the default BLACK.

=> You must FULLY reload KWin once (restart it or log out/in). Use apply.sh
   below, which does everything and tells you exactly what to run.


=========================================================================
EASIEST WAY - run the script
=========================================================================
From the unzipped folder:

    bash BugWindow/apply.sh

It will:
  - install the theme to ~/.local/share/aurorae/themes/BugWindow
  - set the decoration to BugWindow
  - put the buttons in macOS order: close, minimize, maximize on the LEFT
  - tell you the one command to fully restart KWin

Then run the printed restart command (Wayland: kwin_wayland --replace & ,
X11: kwin_x11 --replace &) or just log out and back in.


=========================================================================
MANUAL WAY
=========================================================================
1) Install:
     rm -rf ~/.local/share/aurorae/themes/BugWindow
     unzip BugWindow.zip -d ~/.local/share/aurorae/themes/
   (Must end up at ~/.local/share/aurorae/themes/BugWindow/BugWindowrc)

2) Button position (macOS) - this is a GLOBAL KWin setting, NOT part of the
   theme, so the zip cannot contain it:
     kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key ButtonsOnLeft  XIA
     kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key ButtonsOnRight ""
   (X = close, I = minimize, A = maximize)

3) FULLY restart KWin (required so BugWindowrc is re-read):
     Wayland:  kwin_wayland --replace &
     X11:      kwin_x11 --replace &
   ...or log out / back in.

4) System Settings > Window Decorations > select "BugWindow".


=========================================================================
WHAT IS IN THE rc (already correct)
=========================================================================
- Title color #C7CDFF:  ActiveTextColor / InactiveTextColor = 199,205,255
  (Aurorae has no "TitleColor" key; this is the verified, correct one.)
- TitleAlignment=Center, TitleVerticalAlignment=Center
- Button box 20px, dot ~12px, spacing 5px = same size as your screenshot.


=========================================================================
ABOUT "PERFECTLY CENTERED" TITLE
=========================================================================
KWin's aurorae.qml anchors the title BETWEEN the left button group and the
right button group, then centers it in that gap (this is hard-coded in KWin;
a theme cannot change it). With all buttons on the LEFT (macOS style) and the
right side empty, "Center" therefore centers in the space to the RIGHT of the
buttons - so it sits slightly right of the true window center.

To put the title at the EXACT center of the window with left-only buttons,
balance the sides: System Settings > Window Decorations > "Configure Titlebar
Buttons", and drag a "Spacer" onto the RIGHT side (roughly the same width as
the 3 left buttons). Then the title lands dead center.
