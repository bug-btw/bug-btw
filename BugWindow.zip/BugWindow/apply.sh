#!/usr/bin/env bash
# BugWindow - one-shot installer / fixer for KDE Plasma 6 (KWin).
# Installs the theme, sets macOS button order, and FULLY reloads KWin so the
# theme rc (title color + sizes) is actually re-read.
set -e

THEME="BugWindow"
SRC="$(cd "$(dirname "$0")" && pwd)"               # folder that holds this script
DEST="$HOME/.local/share/aurorae/themes/$THEME"

echo ">> Installing theme to: $DEST"
mkdir -p "$HOME/.local/share/aurorae/themes"
rm -rf "$DEST"
cp -r "$SRC" "$DEST"

RC="$DEST/${THEME}rc"
if [ -f "$RC" ]; then
    echo ">> OK: KWin will read this config file:"
    echo "      $RC"
else
    echo "!! ERROR: $RC not found - the theme folder name must be '$THEME'."
    exit 1
fi

# pick kwriteconfig (Plasma 6 = kwriteconfig6, Plasma 5 = kwriteconfig5)
KW=$(command -v kwriteconfig6 || command -v kwriteconfig5 || true)
QD=$(command -v qdbus6 || command -v qdbus || command -v qdbus-qt6 || true)

if [ -n "$KW" ]; then
    echo ">> Setting decoration to BugWindow + macOS button order (close,min,max on the LEFT)"
    "$KW" --file kwinrc --group org.kde.kdecoration2 --key library "org.kde.kwin.aurorae"
    "$KW" --file kwinrc --group org.kde.kdecoration2 --key theme "__aurorae__svg__$THEME"
    "$KW" --file kwinrc --group org.kde.kdecoration2 --key ButtonsOnLeft "XIA"
    "$KW" --file kwinrc --group org.kde.kdecoration2 --key ButtonsOnRight ""
else
    echo "!! kwriteconfig not found - set buttons manually in System Settings."
fi

# Soft reload (re-reads kwinrc). NOTE: this alone does NOT re-read the theme rc.
[ -n "$QD" ] && "$QD" org.kde.KWin /KWin reconfigure 2>/dev/null || true

echo
echo ">> IMPORTANT: the theme rc (color + sizes) is only re-read when the"
echo "   decoration is re-created. Do ONE of the following now:"
echo "     Wayland:  kwin_wayland --replace &"
echo "     X11:      kwin_x11 --replace &"
echo "   ...or log out and back in."
echo
echo ">> After that, the title should be #C7CDFF and centered. Done."
